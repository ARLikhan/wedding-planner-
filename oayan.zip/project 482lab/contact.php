<?php

<html>
   <head>
   
     <title> CONTACT </title>
	 <link href="style.css" rel="stylesheet" type="text/css">
	 
   </head>
      
	  <body>
	    
		<header>
		  
		  <div class="row">
		  <div class="logo">
		  <img src="logo.PNG">

			</div>
			</div>

		  <div>
		  <ul class="main-nav">
		    <li><a href="index.php"> HOME </a></li>
			<li><a href="services.php"> SERVICES </a></li>
			<li><a href="about.php"> ABOUT </a></li>
			<li class="active"><a href="contact.php"> CONTACT </a></li>
			<li><a href="news.php"> NEWS </a></li>
			<li><a href="faq.php"> FAQ </a></li>
		  </ul>
		 </div>
		 
		 <div class="hero">
			<h1> Group - XX </h1>
			<p1> Group Members: </Br> </p1>
			<p2>
				 1. Md. Shaiful Alam Turza </Br>
				 2. Mohammad Akhlaqur Rahman Likhan </Br>
			</p2>
		</header>
	  </body>

</html>
?>