<?php

<html>
   <head>
   
     <title> CONTACT </title>
	 <link href="style.css" rel="stylesheet" type="text/css">
	 
   </head>
      
	  <body>
	    
		<header>
		  
		  <div class="row">
		  <div class="logo">
		  <img src="logo.PNG">

			</div>
			</div>

		  <div>
		  <ul class="main-nav">
		    <li><a href="index.php"> HOME </a></li>
			<li class="active"><a href="services.php"> SERVICES </a></li>
			<li><a href="about.php"> ABOUT </a></li>
			<li><a href="contact.php"> CONTACT </a></li>
			<li><a href="news.php"> NEWS </a></li>
			<li><a href="faq.php"> FAQ </a></li>
		  </ul>
		 </div>
		 
		 <div class="hero">
			<h1> Our Services </h1>
			<p1> We Provide... </p1>
			
		</header>
	  </body>

</html>
?>