<?php

<html>
   <head>
   
     <title> WEDDING PLANNER WEBSITE </title>
	 <link href="style.css" rel="stylesheet" type="text/css">
	 
   </head>
      
	  <body>
	    
		<header>
		  
		  <div class="row">
		  <div class="logo">
		  <img src="logo.PNG">

			</div>
			</div>

		  <div>
		  <ul class="main-nav">
		    <li class="active"><a href="index.php"> HOME </a></li>
			<li><a href="services.php"> SERVICES </a></li>
			<li><a href="about.php"> ABOUT </a></li>
			<li><a href="contact.php"> CONTACT </a></li>
			<li><a href="news.php"> NEWS </a></li>
			<li><a href="faq.php"> FAQ </a></li>
		  </ul>
		 </div>
		 
         <div class="hero">
		 <h1>best weeding planner in bangladesh</h1>
		   <div class="button">
		     <a href="video.php"class="btn btn-one"> Watch Video </a>
			 <a href="photo.php"class="btn btn-two"> Photo Bucket </a>
			 </div>
			 </div>
		</header>
		
	  </body>
 




</html>
?>